import {Component} from '@angular/core';
import '../css/style.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-social/bootstrap-social.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'ng2-bootstrap';
import 'rxjs/add/operator/toPromise';

@Component({
  selector: 'app',
  templateUrl: 'app.component.html',
  providers: []
})
export class AppComponent{}
