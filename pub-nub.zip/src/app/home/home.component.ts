import {Component} from "@angular/core";
import {FormBuilder, FormGroup} from "@angular/forms";

@Component({
  selector: 'home',
  templateUrl: 'home.component.html',
  providers: []
})

export class HomeComponent {

}
