describe('test', () => {
    it('1+1', () => {
        expect(1 + 1).toBe(3);
    })
});